
SELECT pizza_name, price
FROM Pizzas
ORDER BY price DESC
LIMIT 1;
