
SELECT p.category, SUM(oi.quantity) AS total_quantity
FROM Order_Items oi
JOIN Pizzas p ON oi.pizza_id = p.pizza_id
GROUP BY p.category;
