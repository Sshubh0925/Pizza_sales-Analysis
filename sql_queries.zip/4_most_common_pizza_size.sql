
SELECT size, COUNT(*) AS count
FROM Order_Items oi
JOIN Pizzas p ON oi.pizza_id = p.pizza_id
GROUP BY size
ORDER BY count DESC
LIMIT 1;
