
SELECT order_date::date AS order_date,
       SUM(total_amount) OVER (ORDER BY order_date::date) AS cumulative_revenue
FROM Orders
GROUP BY order_date::date
ORDER BY order_date::date;
