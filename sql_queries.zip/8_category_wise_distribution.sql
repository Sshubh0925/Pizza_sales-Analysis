
SELECT p.category, COUNT(*) AS order_count
FROM Order_Items oi
JOIN Pizzas p ON oi.pizza_id = p.pizza_id
GROUP BY p.category
ORDER BY order_count DESC;
