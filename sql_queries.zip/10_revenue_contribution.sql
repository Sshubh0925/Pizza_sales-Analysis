
SELECT p.pizza_name, 
       SUM(oi.quantity * oi.price) AS revenue,
       (SUM(oi.quantity * oi.price) / (SELECT SUM(total_amount) FROM Orders) * 100) AS percentage_contribution
FROM Order_Items oi
JOIN Pizzas p ON oi.pizza_id = p.pizza_id
GROUP BY p.pizza_name
ORDER BY revenue DESC;
