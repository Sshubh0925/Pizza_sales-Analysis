
SELECT p.pizza_name, SUM(oi.quantity) AS total_quantity
FROM Order_Items oi
JOIN Pizzas p ON oi.pizza_id = p.pizza_id
GROUP BY p.pizza_name
ORDER BY total_quantity DESC
LIMIT 5;
