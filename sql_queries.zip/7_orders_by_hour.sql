
SELECT EXTRACT(HOUR FROM order_date) AS hour, COUNT(*) AS order_count
FROM Orders
GROUP BY hour
ORDER BY hour;
